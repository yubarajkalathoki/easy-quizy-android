package com.easyquizy;

import android.graphics.Color;

/**
 * Created by deepbhai on 8/22/17.
 */

public class ColorSet {
    public static int[] Right_Wrong = {
            Color.rgb(37, 187, 99), Color.rgb(239, 25, 29)
    };
}
